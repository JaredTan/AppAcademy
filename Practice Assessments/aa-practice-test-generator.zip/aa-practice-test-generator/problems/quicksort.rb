class Array

  #Write a monkey patch of quick sort that accepts a block
  def my_quick_sort(&prc)

  end
  
end
