class Array

  def my_rotate(num)

  end

end
