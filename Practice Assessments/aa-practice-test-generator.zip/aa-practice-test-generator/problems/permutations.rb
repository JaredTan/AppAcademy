# Write a recursive method that returns all of the permutations of an array
def permutations(array)
end
