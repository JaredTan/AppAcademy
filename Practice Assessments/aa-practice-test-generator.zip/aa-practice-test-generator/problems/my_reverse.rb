class Array

  def my_reverse

  end

end
