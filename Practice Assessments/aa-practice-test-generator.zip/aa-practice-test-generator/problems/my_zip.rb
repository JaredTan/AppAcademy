class Array

  def my_zip(*arrs)

  end
  
end
