class Array

  def my_each(&prc)

  end

  def my_each_with_index(&prc)

  end
  
end
