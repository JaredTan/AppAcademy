class Array

  def my_reject(&prc)

  end

end
