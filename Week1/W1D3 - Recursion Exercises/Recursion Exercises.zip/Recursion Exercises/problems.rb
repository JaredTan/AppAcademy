
def range(start, ending)
  return [] if ending <= start + 1
  range_length = ending - start - 1
  new_arr = [start + 1]
  range_length.times do |idx|
    new_arr << range(start + 1, ending)[idx] unless idx == range_length - 1
  end
  new_arr
end

def range(min, max)
  arr = []
  ((min + 1)...max).each do |num|
    arr << num
  end
  arr
end

range(3, 10)

def exp(b, n)
  return 1 if n <= 0
  b * exp(b, n - 1)

end

def exp2(b, n)
  return 1 if n <= 0
  return b if n == 1
  p b
  p n
  p '___next recursion___'
  if n.even?
    exp2(b, n / 2) * exp2(b, n / 2)
  else
    b * exp2(b, (n - 1) / 2) * exp2(b, (n - 1) / 2)
  end
end

def deep_dup(arr)
  new_arr = []
  arr.each do |el|
    if el.is_a?(Array)
      new_arr << deep_dup(el)
    else
      new_arr << el
    end
  end
  new_arr
end

def fib_seq(int)
  seq = [0, 1]
  idx = 1

  until idx == int - 1
    seq << seq[idx] + seq[idx - 1]
    idx += 1
  end

  seq
end

def fibs_rec(n)
  if n <= 2
    return [0, 1].take(n)
  else
    fibs = fibs_rec(n - 1)
    fibs << fibs[-2] + fibs[-1]
  end
end

def fib_seq2(int)
  seq = [0, 1]
  return [0, 1] if int == 1
  prev_seq = fib_seq2(int - 1)

  (2...int).each do |i|
    seq << prev_seq[i - 2] + prev_seq[i - 1]
  end

  seq
end
#
class Array
  def subsets
    return [[]] if empty?
    subs = self.take(self.count - 1).subsets
    p subs
    subs + (subs.map { |sub| sub + [self.last] })
  end
end

[1,2,3].subsets
#
def subsets2(array)
  return [[]] if array.empty?
  subs = subsets2(array.take(array.count - 1))
  p "#{subs} subs2"
  subs + (subs.map { |sub| p (sub + [array.last] ) })
end

p subsets2([1,2,3])
# #
def subsets(array)
  return [[]] if array.empty?
  subs = subsets(array[0..-2])
  # sub_array = []
  # p subs
  changed_subs = subs.map do |sub|
    sub + [array[-1]]
  end
  subs + changed_subs
end



def subsets(array)
  return [[]] if array.empty?
  subs = subsets(array[0..-2])
  sub_array = []
  # sub_array = []
  # p subs
  subs.each do |sub|
    # sub_array << sub + [array[-1]]
    sub2 = sub + [array[-1]]
    sub_array << sub2
  end
  subs + sub_array
end

subsets([1,2,3])

end
# #
def permutations(array)

  return [[]] if array.empty?
  sub_array = []
  subs = permutations(array[0..-2])
  p subs

  subs.each do |el|
    (0..el.length).each do |i|
      sub_array << el[0...i] + [array.last] + el[i..-1]
    end
  end
  sub_array
end

def permutations(array)
  return [[]] if array.empty?
  sub_array = []
  subs = permutations(array[0...-1])

  subs.each do |sub|
    lala = sub.unshift(array.last).dup
    array.length.times do
      sub_array << lala.unshift(lala.pop)
    end
  end
  sub_array
end

p permutations([1,2,3])

new_arr = permutations([1,2,3,4])

new_arr[0][0] = 'test'
p new_arr



p permutations([1, 2, 3, 4])
