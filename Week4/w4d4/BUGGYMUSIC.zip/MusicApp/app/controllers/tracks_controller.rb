class TracksController < ApplicationController
end
