class ApplicationMailer < ActionMailer::Base
  default from: 'from@example.com'
  layout 'mailer'

  def welcome_email(user)
    @user = user
    @url = www.facebook.com/lee.cjanet
    mail(to: 'potatoes1229@yahoo.com', subject: "Bands for days!")
  end
end
